module.exports.listar_produtos = function (app, req, res) {
    const conexao = app.config.conexao;
    const modelProduto = new app.app.models.modelProduto(conexao);

    modelProduto.getProdutos(function (error, result) {
        res.render('produto/listaProdutos', {erros: {}, produtos: result})
    });
}