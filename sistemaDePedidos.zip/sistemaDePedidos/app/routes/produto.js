module.exports = function (app) {
    app.get('/produtos', function (req, res) {
        app.app.controllers.produto.listar_produtos(app, req, res);
    });
}