const app = require('./config/server')();

app.listen(80, function () {
    console.log('Server running!');
})